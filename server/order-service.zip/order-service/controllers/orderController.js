const Order = require('../models/Order');
const Product = require('../../product-service/models/Product'); // import Product model

const getOrders = async (req, res) => {
  const { userId } = req.query;
  try {
    const filter = userId ? { userId } : {};
    const orders = await Order.find(filter).populate('items.productId');
    res.status(200).json(orders);
  } catch (error) {
    res.status(500).json({ message: 'Error fetching orders', error: error.message });
  }
};

const createOrder = async (req, res) => {
  const { userId, items } = req.body;

  if (!userId || !Array.isArray(items) || items.length === 0) {
    return res.status(400).json({ message: 'userId and items are required' });
  }

  try {
    // 1. Check stock availability
    for (const item of items) {
      const product = await Product.findById(item.productId);
      if (!product) {
        return res.status(404).json({ message: `Product not found: ${item.productId}` });
      }
      if (product.stock < item.quantity) {
        return res.status(400).json({ message: `Insufficient stock for product: ${product.name}` });
      }
    }

    // 2. Deduct stock for each item
    for (const item of items) {
      await Product.findByIdAndUpdate(item.productId, { $inc: { stock: -item.quantity } });
    }

    // 3. Save order
    const order = new Order({ userId, items });
    await order.save();

    res.status(201).json({ message: 'Order created and stock deducted', order });
  } catch (error) {
    res.status(500).json({ message: 'Error creating order', error: error.message });
  }
};

module.exports = {
  getOrders,
  createOrder,
};
